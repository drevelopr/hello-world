# hello-world
Andre C here. C stands for "cute," as it is the cutest programming language.  ;-)
